
class Wizard:
  def __init__(self, name):
    self.name = name
    self.mana = 100
    self.health = 100
  
  def getMana(self):
    return self.mana
  def getHealth(self):
    return self.health
  def attack(self, enemy):
    enemy.health -= 10
    self.mana -= 10
goodWizard = Wizard("Gandalf")
badWizard = Wizard("Sauron")

print(goodWizard.name + " health:")
print(goodWizard.getHealth())
print(goodWizard.name + " mana:")
print(goodWizard.getMana())

print(badWizard.name + " health:")
print(badWizard.getHealth())
print(badWizard.name + " mana:")
print(badWizard.getMana())

print(goodWizard.name + " attacking " + 
      badWizard.name)
goodWizard.attack(badWizard)

print(goodWizard.name + " health:")
print(goodWizard.getHealth())
print(goodWizard.name + " mana:")
print(goodWizard.getMana())

print(badWizard.name + " health:")
print(badWizard.getHealth())
print(badWizard.name + " mana:")
print(badWizard.getMana())

'''
  Run the above code, read it, then
  comment it out.

  1. How many different Wizard objects
    were created?
3
  2. What are the Wizard object's names?
Gandalf and Sauron
  3. What is the value stored in each of the
    Wizard objects' name variable/property?
the name of the wizards listed above
  4. Besides name, what are the two other
    properties given to every Wizard object?
health and mana
  5. What value is stored in each of the 
    constructed Wizard objects above when 
    they are first constructed?
  100
  6. How have those values changed once the
    script is run?
when they are attacked/attacking
  7. What does the attack() function do? How
    does it impact various Wizard objects' 
    properties? Which properties for which
    objects in what ways?
  Takes away health to one of the wizards,it subracts the wizards health.
  8. Now, uncomment the following code...
'''

'''
class Wizard:
  def __init__(self, name):
    self.name = name
    self.mana = 100
    self.health = 100
  
  def getMana(self):
    return self.mana

  def getHealth(self):
    return self.health

  def attack(self, enemy):
    enemy.health -= 10
    self.mana -= 10

  def heal(self):
    self.health += 10
    self.mana -= 10

  def rechargeMana(self):
    self.mana += 10

playerOne = Wizard("Ruijerd")
playerTwo = Wizard("Romaji")

while True:
  print("Simulating Battle...")
  print(playerOne.name + " Health:")
  print(playerOne.getHealth())
  print(playerOne.name + " Mana:")
  print(playerOne.getMana())
  print(playerTwo.name + " Health:")
  print(playerTwo.getHealth())
  print(playerTwo.name + " Mana:")
  print(playerTwo.getMana())

  print(playerOne.name + " attacks " + playerTwo.name)
  playerOne.attack(playerTwo)
  if playerTwo.health <= 0:
    print(playerTwo.name + " dead")
    break
  print(playerTwo.name + " attacks " + playerOne.name)
  playerTwo.attack(playerOne)
  if playerTwo.health <= 0:
    print(playerTwo.name + " dead")
    break
  
'''

'''
  9. Run the above program.

  10. How many wizard objects are created
    in the above program?
  
  11. When those objects are created, what
    are the values stored in their properties?

  12. What happens to the values in those
    properties while the programming is 
    running?

  13. What does the heal() function do?
adds 10 health
  14. Is the heal() function ever called
    during the execution of the program?
no
  15. What would happen if every time the
    attack function was called, both objects
    also called the heal() function?
  it would cancel out and their health would not be affected
  16. What would happen if every time through
  the loop, playerOne called the heal() function?
playerOne would be at 100 throughout the program
  17. What would happen if every time through
  the loop, playerTwo called the heal() function?
playerTwo would be at 100 throughout the program
  18. What does the rechargeMana() function do?
adds 10 mana 
  19. Is the rechargeMana() function ever called?
no
  20. How would the output of the program change
    if each object called the rechargeMana() 
    function each time through the loop?
    Their health would be affected but they would have 100 mana through the program
  '''
